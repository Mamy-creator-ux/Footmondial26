"use client"

import Link from "next/link"
import { ArrowLeft, ArrowUpRight } from "lucide-react"
import { FormEvent, useState } from "react"

export default function ConnexionPage() {
  const [submitted, setSubmitted] = useState(false)

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setSubmitted(true)
  }

  return (
    <main className="min-h-screen bg-[#050505] px-5 py-6 text-[#f1f0eb] md:px-10 md:py-8">
      <header className="flex items-center justify-between border-b border-white/15 pb-5">
        <Link href="/" className="font-mono text-sm font-bold tracking-[-0.08em]">FIFA<span className="text-[#ee3d2f]">26</span><span className="ml-1 text-xs font-normal tracking-normal text-white/60">/ CONTROL</span></Link>
        <Link href="/" className="font-mono text-[10px] uppercase tracking-widest text-white/60 transition-colors hover:text-white"><ArrowLeft className="mr-2 inline" size={13}/> Retour</Link>
      </header>
      <section className="mx-auto grid min-h-[calc(100vh-120px)] max-w-6xl items-center gap-16 py-16 md:grid-cols-[1fr_430px]">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-[#ef3f30]">Espace sécurisé // FIFA26</p>
          <h1 className="mt-6 text-7xl font-medium leading-[.84] tracking-[-.09em] md:text-[10rem]">Bon<br/><span className="text-[#ef3f30]">retour.</span></h1>
          <p className="mt-8 max-w-md text-lg leading-relaxed text-white/50">Accédez à votre tableau de bord, vos équipes suivies et vos alertes de match.</p>
        </div>
        <form onSubmit={handleSubmit} className="border border-white/15 bg-white/[.03] p-6 md:p-8">
          <div className="mb-8 flex items-center justify-between border-b border-white/15 pb-5"><span className="font-mono text-[10px] uppercase tracking-widest">Connexion</span><ArrowUpRight size={16} className="text-[#ef3f30]"/></div>
          <label className="font-mono text-[10px] uppercase tracking-widest text-white/50">Adresse e-mail<input required type="email" autoComplete="email" placeholder="vous@exemple.com" className="mt-3 w-full border-b border-white/25 bg-transparent px-0 py-3 font-sans text-lg outline-none transition-colors placeholder:text-white/25 focus:border-[#ef3f30]"/></label>
          <label className="mt-7 block font-mono text-[10px] uppercase tracking-widest text-white/50">Mot de passe<input required minLength={6} type="password" autoComplete="current-password" placeholder="••••••••" className="mt-3 w-full border-b border-white/25 bg-transparent px-0 py-3 font-sans text-lg outline-none transition-colors placeholder:text-white/25 focus:border-[#ef3f30]"/></label>
          <button type="submit" className="mt-9 w-full bg-[#f0efea] px-4 py-4 font-mono text-[10px] uppercase tracking-widest text-black transition-colors hover:bg-[#ef3f30] hover:text-white">{submitted ? "Connexion simulée" : "Entrer dans Control"}<ArrowUpRight className="ml-2 inline" size={14}/></button>
          {submitted && <p role="status" className="mt-4 font-mono text-[10px] uppercase leading-relaxed text-[#ef3f30]">Interface prête. L&apos;authentification serveur sera branchée sur votre base de données.</p>}
          <p className="mt-8 border-t border-white/10 pt-5 font-mono text-[10px] uppercase leading-relaxed text-white/35">Pas encore de compte ? Contactez l&apos;administrateur de la plateforme.</p>
        </form>
      </section>
    </main>
  )
}
